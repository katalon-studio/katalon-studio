package com.katalon.kata.sample;

public class Constants {

  public static String baseUrl = "http://demoaut.katalon.com";
  public static String username = "John Doe";
  public static String password = "ThisIsNotAPassword";
}
